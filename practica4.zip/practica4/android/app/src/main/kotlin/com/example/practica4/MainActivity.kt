package com.example.practica4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
