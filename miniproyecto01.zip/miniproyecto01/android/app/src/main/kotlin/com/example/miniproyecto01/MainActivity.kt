package com.example.miniproyecto01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
