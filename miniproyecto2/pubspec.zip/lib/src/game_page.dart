import 'dart:async';
import 'package:flutter/material.dart';
import 'package:memorama/src/card_widget.dart';
import 'package:memorama/src/record_manager.dart';

class GamePage extends StatefulWidget {
  final int numPairs;

  GamePage({required this.numPairs});

  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  late Timer _timer;
  int _seconds = 0;
  bool _gameOver = false;
  late List<String> _images;
  late List<bool> _revealed;

  @override
  void initState() {
    super.initState();
    _startGame();
  }

  void _startGame() {
    _images = _generateImageList();
    _revealed = List.generate(widget.numPairs * 2, (_) => false);
    _timer = Timer.periodic(Duration(seconds: 1), (Timer timer) {
      if (_gameOver) {
        timer.cancel();
      } else {
        setState(() {
          _seconds++;
        });
      }
    });
  }

  List<String> _generateImageList() {
    List<String> baseImages = [
      'cerdo.png', 'gato.png', 'leon.png', 'perro.png', 'pez.png', 'tortuga.png'
    ];

    // Dependiendo del número de pares, seleccionamos las imágenes necesarias.
    List<String> selectedImages;

    // Selecciona imágenes dependiendo del nivel.
    if (widget.numPairs == 8) {
      selectedImages = baseImages.sublist(0, 4); // 4 imágenes para 8 pares
    } else if (widget.numPairs == 10) {
      selectedImages = baseImages.sublist(0, 5); // 5 imágenes para 10 pares
    } else if (widget.numPairs == 12) {
      selectedImages = baseImages.sublist(0, 6); // 6 imágenes para 12 pares
    } else {
      selectedImages = []; // Para evitar errores en otros casos
    }

    // Creamos los pares duplicando las imágenes y las mezclamos.
    List<String> imagePairs = [...selectedImages, ...selectedImages]..shuffle();

    return imagePairs;
  }

  void _checkGameOver() {
    if (!_revealed.contains(false)) {
      setState(() {
        _gameOver = true;
      });
      RecordManager.saveRecord(widget.numPairs, _seconds);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepOrange[200],
        title: Text('Memorama - ${widget.numPairs} pares'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Text(
            'Tiempo: $_seconds segundos',
            style: TextStyle(fontSize: 24),
          ),
          Expanded(
            child: GridView.builder(
              itemCount: _images.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
              ),
              itemBuilder: (context, index) {
                return CardWidget(
                  imagePath: _images[index],
                  revealed: _revealed[index],
                  onTap: () {
                    setState(() {
                      _revealed[index] = !_revealed[index];
                    });
                    _checkGameOver();
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
}